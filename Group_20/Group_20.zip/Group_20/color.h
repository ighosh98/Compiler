/*
Group 20
Ayush Vachaspati 2016B3A70398P
Indraneel Ghosh  2016B1A70938P
G Adityan	 2016B1A70929P
*/
#ifndef COLOR
#define COLOR
#include <stdio.h>

void red();
void blue();
void yellow();
void green();
void reset();
#endif
