/*
   Group 20
   Ayush Vachaspati 2016B3A70398P
   Indraneel Ghosh  2016B1A70938P
   G Adityan	 2016B1A70929P
*/

#ifndef TREEFILES_H
#define TREEFILES_H
int naryTreesize(treenode* root);
int ASTsize(astnode* root);
#endif
