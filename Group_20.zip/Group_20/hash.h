/*
Group 20
Ayush Vachaspati 2016B3A70398P
Indraneel Ghosh  2016B1A70938P
G Adityan	 2016B1A70929P
*/
#ifndef HASHFUNC
#define HASHFUNC
#include<stdio.h>

unsigned int hashf(char * str);

#endif
