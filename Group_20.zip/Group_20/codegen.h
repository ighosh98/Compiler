/*
Group 20
Ayush Vachaspati 2016B3A70398P
Indraneel Ghosh  2016B1A70938P
G Adityan	 2016B1A70929P
*/
#ifndef CODEGEN_H
#define CODEGEN_H
#include <stdio.h>
#include "lexerDef.h"
#include "ast.h"
#include "astdef.h"
#include <string.h>
#include "symboltable.h"
#include "semantic.h"
#include "color.h"
extern FILE* code_file;
extern symbolTable* top_table;
int codegen(astnode*, symbolTable*, int);

#endif
